import 'package:flutter/material.dart';
import 'app_colors.dart';

class AppTheme {
  // ✅ Splash Gradient (مستوحى من الأخضر الطبي)
  static const splashGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      AppColors.primaryDark,
      AppColors.primary,
    ],
  );

  // ✅ Splash Title Style (شعار كبير)
  static const splashTitleTextStyle = TextStyle(
    fontSize: 36,
    fontWeight: FontWeight.bold,
    color: Colors.white,
    fontFamily: 'Tajawal',
    letterSpacing: 1.2,
    shadows: [
      Shadow(
        blurRadius: 6,
        color: Colors.black26,
        offset: Offset(0, 2),
      ),
    ],
  );

  // ✅ Splash Subtitle Style (وصف خفيف)
  static const splashSubtitleTextStyle = TextStyle(
    fontSize: 16,
    color: Colors.white70,
    fontFamily: 'Tajawal',
  );

  // ✅ ThemeData الموحد لكل التطبيق
  static ThemeData get light => ThemeData(
        useMaterial3: true,
        fontFamily: 'Tajawal',
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          primary: AppColors.primary,
          secondary: AppColors.secondary,
          background: AppColors.background,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            minimumSize: const Size(double.infinity, 48),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: AppColors.primaryDark,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          hintStyle: const TextStyle(
            color: AppColors.grey,
          ),
          labelStyle: const TextStyle(
            color: AppColors.text,
            fontWeight: FontWeight.w500,
          ),
        ),
      );
}
