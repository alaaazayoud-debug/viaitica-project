import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final List<TextEditingController> _controllers =
      List.generate(4, (_) => TextEditingController());
  final List<FocusNode> _focusNodes = List.generate(4, (_) => FocusNode());

  String phone = '';
  String pharmacyName = '';
  String _message = '';
  bool _isVerifying = false;
  int _seconds = 30;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startCountdown();
  }

  void _startCountdown() {
    _seconds = 30;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _seconds--;
        if (_seconds <= 0) {
          timer.cancel();
        }
      });
    });
  }

  void _verifyCode() {
    final code = _controllers.map((c) => c.text).join();
    if (code == '1234') {
      setState(() => _message = '');
      GoRouter.of(context).go('/home');
    } else {
      setState(() => _message = '❌ الرمز غير صحيح، جرب 1234');
    }
  }

  void _onChanged(String value, int index) {
    if (value.length == 1 && index < 3) {
      _focusNodes[index + 1].requestFocus();
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final uri = GoRouterState.of(context).uri;
    phone = uri.queryParameters['phone'] ?? '';
    pharmacyName = uri.queryParameters['pharmacy'] ?? '';
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    for (final f in _focusNodes) {
      f.dispose();
    }
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('رمز التحقق'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          reverse: true,
          padding: EdgeInsets.only(
            left: 24,
            right: 24,
            top: 24,
            bottom: MediaQuery.of(context).viewInsets.bottom + 24,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 16),
              Text(
                'أدخل الرمز المرسل إلى:\n📞 $phone',
                style: const TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(
                  4,
                  (i) => SizedBox(
                    width: 60,
                    child: TextField(
                      controller: _controllers[i],
                      focusNode: _focusNodes[i],
                      keyboardType: TextInputType.number,
                      maxLength: 1,
                      textAlign: TextAlign.center,
                      decoration: const InputDecoration(counterText: ''),
                      onChanged: (val) => _onChanged(val, i),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _isVerifying ? null : _verifyCode,
                child: _isVerifying
                    ? const CircularProgressIndicator()
                    : const Text('تحقق'),
              ),
              const SizedBox(height: 16),
              Text(
                _message,
                style: const TextStyle(color: Colors.red),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              if (_seconds > 0)
                Text('🔁 يمكنك إعادة الإرسال خلال: $_seconds ثانية')
              else
                TextButton(
                  onPressed: () {
                    _controllers.forEach((c) => c.clear());
                    _startCountdown();
                    setState(() => _message = 'تمت إعادة الإرسال (وهمية ✅)');
                  },
                  child: const Text('إعادة الإرسال'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
