import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';
import 'package:dighri_customer/constants/app_colors.dart';

class PhoneEntryScreen extends StatefulWidget {
  const PhoneEntryScreen({super.key});

  @override
  State<PhoneEntryScreen> createState() => _PhoneEntryScreenState();
}

class _PhoneEntryScreenState extends State<PhoneEntryScreen> {
  final TextEditingController _pharmacyNameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  String? _validatePharmacy(String? value) {
    if (value == null || value.isEmpty) return 'أدخل اسم الصيدلية';
    if (value.length < 2) return 'الاسم قصير جدًا';
    return null;
  }

  String? _validatePhone(String? value) {
    if (value == null || value.isEmpty) return 'أدخل رقم الهاتف';
    if (!value.startsWith('09')) return 'يجب أن يبدأ بـ 09';
    if (value.length != 10) return 'يجب أن يكون 10 أرقام';
    return null;
  }

  void _submitForm() {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    final fullPhone = '+963${_phoneController.text.trim()}';
    final pharmacyName = _pharmacyNameController.text.trim();

    Future.delayed(const Duration(seconds: 1), () {
      GoRouter.of(context).push('/otp?phone=$fullPhone&pharmacy=$pharmacyName');
    });
  }

  @override
  void dispose() {
    _pharmacyNameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: SvgPicture.asset(
              'assets/images/wave_bg.svg',
              fit: BoxFit.cover,
              height: 120,
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SvgPicture.asset('assets/images/logo.svg', height: 90),
                    const SizedBox(height: 24),
                    const Text(
                      'مرحبًا بك في دغري فارم!',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primaryDark,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'يرجى إدخال بياناتك للمتابعة',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 32),

                    // 🏪 اسم الصيدلية
                    TextFormField(
                      controller: _pharmacyNameController,
                      decoration: const InputDecoration(
                        labelText: 'اسم الصيدلية',
                        hintText: 'مثل: صيدلية البيان',
                        prefixIcon: Icon(Icons.local_pharmacy_outlined),
                      ),
                      validator: _validatePharmacy,
                    ),
                    const SizedBox(height: 16),

                    // 📱 رقم الهاتف
                    TextFormField(
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                        labelText: 'رقم الهاتف',
                        hintText: 'مثال: 0987654321',
                        prefixIcon: Icon(Icons.phone_android),
                      ),
                      validator: _validatePhone,
                    ),
                    const SizedBox(height: 20),

                    // 🌍 زر اختيار الموقع
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text('قريبًا: اختيار الموقع')),
                          );
                        },
                        icon: const Icon(Icons.location_on_outlined, size: 20),
                        label: const Text('اختيار الموقع'),
                        style: TextButton.styleFrom(
                          foregroundColor: AppColors.primaryDark,
                        ),
                      ),
                    ),

                    const SizedBox(height: 28),

                    // ✅ زر التالي
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _submitForm,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          minimumSize: const Size(0, 48),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child:
                                    CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Text('التالي'),
                      ),
                    ),
                    const SizedBox(height: 60),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
